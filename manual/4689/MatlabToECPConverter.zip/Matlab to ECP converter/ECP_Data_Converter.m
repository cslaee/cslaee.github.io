function varargout = ECP_Data_Converter(varargin)




% Dr. Rad 7/7/16
% 



% ECP_DATA_CONVERTER MATLAB code for ECP_Data_Converter.fig
%      ECP_DATA_CONVERTER, by itself, creates a new ECP_DATA_CONVERTER or raises the existing
%      singleton*.
%
%      H = ECP_DATA_CONVERTER returns the handle to a new ECP_DATA_CONVERTER or the handle to
%      the existing singleton*.
%
%      ECP_DATA_CONVERTER('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ECP_DATA_CONVERTER.M with the given input arguments.
%
%      ECP_DATA_CONVERTER('Property','Value',...) creates a new ECP_DATA_CONVERTER or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ECP_Data_Converter_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ECP_Data_Converter_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ECP_Data_Converter

% Last Modified by GUIDE v2.5 24-Sep-2015 11:12:55

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ECP_Data_Converter_OpeningFcn, ...
                   'gui_OutputFcn',  @ECP_Data_Converter_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end
clc;
if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ECP_Data_Converter is made visible.
function ECP_Data_Converter_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ECP_Data_Converter (see VARARGIN)

% Choose default command line output for ECP_Data_Converter
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes ECP_Data_Converter wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = ECP_Data_Converter_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in buttonSelect.
function buttonSelect_Callback(hObject, eventdata, handles)
% hObject    handle to buttonSelect (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[FileName,PathName] = uigetfile('.txt', 'Select your data file');
if FileName~=0
    set(handles.Status, 'string', strcat('You have chosen file:', FileName));
    fid = fopen(strcat(PathName, FileName));
    handles.data.Variables = {};
    handles.data.data = [];
    handles.data.FileName = strrep(FileName, '.txt', '');
    line_number = 0;
    keep_going = 1;
    found_first_bracket = 0;
    line = fgetl(fid);
    handles.data.Variables = strrep(strsplit(line, '  '), ' ', '');    
    while keep_going
        line = fgetl(fid); % Read a new line from the template file
        % fprintf(1,'%s\n',line);
        if ~ischar(line) % Make sure it is a string
            keep_going = 0;  % Not a string... must be done with the file!        
        else   % Got a good line!
            line_number = line_number+1;
            found_it = ~isempty(strfind(line, '['));
            if found_it
                found_first_bracket = 1;
            end
            if 1==found_first_bracket  % First bracket was already found, looking for end bracket now
                found_it=~isempty(strfind(line,']')); 
                line = strrep(line, ']', '');
                line = strrep(line, '[', '');
                handles.data.data = [handles.data.data;double(str2num(line))];
                if 1==found_it  % Bracket was found
                    keep_going = 0; % Forces the function to quit
                end
            end% Ends check to see if looking for first bracket
        end  % Ends check to see if a good line
    end  % Ends looping through file
else
    set(handles.Status, 'string', 'No file seleted.');
end

guidata(hObject, handles);

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

plot(handles.axes1, handles.data.data(:, 2), handles.data.data(:, 3:end));
legend(handles.data.Variables{3:end});
grid on;
text(0, 0.5, {'Please export data to plot your', 'own diagrams and label axes.'},...
    'color', 'red', 'Parent', handles.axes1, 'fontsize', 14, 'units', 'normalized');
set(handles.Status, 'string', 'A plot has been generated.');


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

defAnswer=handles.data.FileName;

data=handles.data.data;
[dataFileName, dataPathName] = uiputfile('.mat', 'Save your data as', defAnswer);

if ~isempty(dataFileName)
    [r, c] = size(data);
    for i = 2:c
        eval(sprintf('%s = data(:, i)', handles.data.Variables{i}));
    end
    clc;
    save(strcat(dataPathName, dataFileName), handles.data.Variables{2:end});
    set(handles.Status, 'string', 'Data have been saved.');
else
    set(handles.Status, 'string', 'Data are not saved.');
end
