%This script is for getting Bode plots of a PID controller with and w/o a lead 
%lag filter for higher freq disturb attenuation.  It also calculates the discrete time 
% controller coefficients for the lead/lag filter using the FOH conversion
% The closed loop transf %function is Y(s)/Fd(s)
% You must first run SISOplant.m, PD desgner.m

%Inputs
ki=10; %Integrator gain
z1=0.25; %Lead zero for lead/lag filter in Hz
p1=1.5; %Lag pole for lead/lag filterin Hz
Ts=0.001768; %Sampling period for use in calculating lead/lag real-time discrete coefficients


%Basic system ki�0
Nol1=ksys1*[kd kp ki];
Dol1=m*[1 0 0 0];
w=logspace(-1,3,400);
magol1=bode(Nol1,Dol1,w);
Ncl1=[1 0];Dcl1=Dol1+[0 Nol1];
magcl1=bode(Ncl1,Dcl1,w);

%For ki=0:
ki=0;
Nol2=ksys1*[kd kp ki];
Dol2=m*[1 0 0 0];
magol2=bode(Nol2,Dol2,w);
Ncl2=[1 0];Dcl2=Dol1+[0 Nol2];
magcl2=bode(Ncl2,Dcl2,w);

%Add lead/lag
Nfilt=[p1/z1 p1*2*pi];
Dfilt=[1 p1*2*pi];
Nol3=conv(Nol2,Nfilt);
Dol3=conv(Dol2,Dfilt);
magol3=bode(Nol3,Dol3,w);
Ncl3=conv([1 0],Dfilt);Dcl3=Dol3+[0 Nol3];
magcl3=bode(Ncl3,Dcl3,w);

%Look @ Y(s)/Fd(s) of all the above:

%semilogx(w/2/pi,20*log10([magcl1 magcl2 magcl3])),set(gca,'xtick',[.2 .3 .4 .5 .6 .7 .8 .9 1 2 3 4 5 6 7 8 9 10 20 30 40 50 60 70 80 90]),grid,axis([0.1 100 -100 0])
%Open Loop
semilogx(w/2/pi,20*log10(magol1),'--',w/2/pi,20*log10(magol2),'-',w/2/pi,20*log10(magol3),':'),
grid,axis([0.1 100 -30 70]), 
set(gca,'xtick',[.2 .3 .4 .5 .6 .7 .8 .9 1 2 3 4 5 6 7 8 9 10 20 30 40 50 60 70 80 90]),
xlabel('Frequency (Hz)'), ylabel('Magnitud (Db)'),title('"-" PD,             "--" PD+Integrator",           ":" PD+Lead/Lag')
pause
%Closed Loop
semilogx(w/2/pi,20*log10(magcl1),'--',w/2/pi,20*log10(magcl2),'-',w/2/pi,20*log10(magcl3),':'),
grid,axis([0.1 100 -100 0]), 
set(gca,'xtick',[.2 .3 .4 .5 .6 .7 .8 .9 1 2 3 4 5 6 7 8 9 10 20 30 40 50 60 70 80 90]),
xlabel('Frequency (Hz)'), ylabel('Magnitud (Db)'),title('"-" PD,             "--" PD+Integrator",           ":" PD+Lead/Lag')

%Discrete time lead-lag coefficients
H=tf(Nfilt,Dfilt)
Hd=c2d(H,Ts)

