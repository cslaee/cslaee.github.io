% PDPOLEPACE.M
% This script first solves for the PD gains kp & kd for the collocated inner 
% loop, then the state feedback gain vector Klqr for control of the outer (y2)
% You must first run MIMOplant.m and set SIMO=1
% For discrete implementation, input sampling rate (sec)
Ts=0.001768;   

% INNER LOOP PD CONTROL
% Input desired natural frequency, wnhz (Hz), and damping ratio, z
wnhz=8;
wn=wnhz*2*pi;
z=1;

% Calculate kp & kd.
kp=wn^2*m/ksys
kd=2*z*sqrt(m*kp/ksys)

% For mechanical parameter forms of Nstr, & Dstr: (Comment out if not used)
%Designate damping coefficient, c_
c_=8*m
Nstr=k12prm/m
Dstr=[1 c_/m k12prm/m]
AA=[[0 1];[-k12prm/m -c_/m]],BB=[0;k12prm/m],CC=[1 0],DD=0



% LQR synthesis for outper loop SISO
Q=CC'*CC;
Klqr1=lqr(AA,BB,Q,10);
Klqr2=lqr(AA,BB,Q,1);
Klqr3=lqr(AA,BB,Q,.6);
Klqr4=lqr(AA,BB,Q,.4);
Klqr5=lqr(AA,BB,Q,.2);
Klqr6=lqr(AA,BB,Q,.1);
% Calculate closed loop poles assuming inner loop has infinite bandwidth
Pcl1=eig(AA-BB*Klqr1)/2/pi;
Pcl2=eig(AA-BB*Klqr2)/2/pi;
Pcl3=eig(AA-BB*Klqr3)/2/pi;
Pcl4=eig(AA-BB*Klqr4)/2/pi;
Pcl5=eig(AA-BB*Klqr5)/2/pi;
Pcl6=eig(AA-BB*Klqr6)/2/pi;
% Plot Roots
plot(Pcl1,'x')
axis([-8,1,-8,8])
hold;
plot(Pcl2,'o');
plot(Pcl3,'*');
plot(Pcl4,'+');
plot(Pcl5,'.');
plot(Pcl5,'o');
plot(Pcl6,'*');
plot(Pcl6,'o');
title('LQR Controller, Closed Loop Poles For Various Control Effort Weights')
xlabel('Real  (Hz)')
ylabel('Imaginary  (Hz)')
grid;
hold;
pause
% Continuous time step responses:
t=0:.01:1;
steplq1=(1+Klqr1(1))*step([AA-BB*Klqr1],BB,CC,0,1,t);
steplq2=(1+Klqr2(1))*step([AA-BB*Klqr2],BB,CC,0,1,t);
steplq3=(1+Klqr3(1))*step([AA-BB*Klqr3],BB,CC,0,1,t);
steplq4=(1+Klqr4(1))*step([AA-BB*Klqr4],BB,CC,0,1,t);
steplq5=(1+Klqr5(1))*step([AA-BB*Klqr5],BB,CC,0,1,t);
steplq6=(1+Klqr6(1))*step([AA-BB*Klqr6],BB,CC,0,1,t);
%Example Step Response Plot
axis([0,1,0,1.5]);
plot(t,[steplq1 steplq2 steplq3 steplq4 steplq5]);grid

