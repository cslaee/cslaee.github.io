% This script builds the linearized SISO plant model about some operating point, y1o, 
% u1o for the lower (repulsive) plant and y2o, u2o for the upper (attractive) plant.   
% You must first have run "sensorcal.m" (both sensors), "magnet2magnetcal.m" and 
% "actuatorcal.m" or input parameters manually

%FORMS OF OUTPUT:
% Transfer matrix: Y(s) = G(s)*U(s), 
				   % Y & U are the output and input vectors respectively
				   % G(s)=[[Num11(s)/D(s) Num12(s)/D(s)];[Num21(s)/D(s) Num22(s)/D(s)]]
% State Space:	   Ydot = A*Y + B*U,  YY = C*Y
				   % A, B, C are the system, input, and output matrices respectively

% USER INPUTS

modeltype=2  % Choose plant model type (0=linearized about equilibrium 
			 % using raw sensor counts, 1=linearized about equilibrium
			 % using calibrated/corrected sensor, 2= operation throughout
			 % range, using corrected sensor & actuator with magnetic coupling 
			 % linearized as spring about operating point
SIMO=0 % 0=MIMO,1=SIMO with input at lower magnet (modify below for upper magnet input)
m=0.121  % magnet mass (kg)
W=m*9.81 % magnet weight
y1o=1 % Offset position1 (cm)
yraw1o=21400 %typical value when y1o=1 cm., typical value when y1o=1
y2o=-2 % Offset position2 (cm)\
%y2o=-4.2 %typical value for SIMO, when y1o=1 cm.
yraw2o=15400 % Raw sensor counts at offset2 (counts), typical value when y2o=-2
%yraw2o=22100 % typical value when y2o=-1 cm
yc=13.3 % Maximum possible magnet separation (cm)

% Calculated Parameters
y12o=yc-y1o+y2o % Separation of magnets at equilibrium
k1prm=4/(y1o+b1)*W*100 % Effective linearized spring constant (N/m)
ku1str=1/(a1*(b1+y1o)^4) % Actuator gain (N/count)
k2prm=4/(y2o+b2)*W*100 % Effective linearized spring constant (N/m)
ku2str=1/(a2*(b2+y2o)^4) % Actuator gain (N/count)
k12prm=4*c/(y12o+d)^5*100 %Linearized intermagnet force MULTIPLIED by 100 for units of N/m

% Model Building
if modeltype==0
	ksens1=1/(-e1*(yraw1o)^(-2)-f1/2*(yraw1o)^(-1.5)+h1)*100 % Sensor1 gain at equilib (counts/m)
	ksens2=1/(-e2*(yraw2o)^(-2)-f2/2*(yraw2o)^(-1.5)+h2)*100 % Sensor2 gain at equilib (counts/m)
end
if modeltype==1
	ksens1=10^6 % Sensor gain (counts/m)
	ksens2=10^6
end
    
if modeltype~=2
	u1o=a1*(y1o+b1)^4*(W+c/(y12o+d)^4) % Control effort actuator1 @ equilibrium (counts)
	u2o=a2*(y2o+b2)^4*(W-c/(y12o+d)^4) % Control effort actuator2 @ equilibrium (counts)
	Num11 = ksens1*ku1str*[m 0 k12prm-k2prm]/m^2
	Num12 = ksens1*k12prm*ku2str/m^2
	Num21 = ksens2*k12prm*ku1str/m^2
	Num22 = ksens2*ku2str*[m 0 k1prm+k12prm]/m^2
	Den = [1 0 (k1prm+2*k12prm-k2prm)/m 0 (k1prm*k12prm-k1prm*k2prm-k2prm*k12prm)/m^2]
	A=[[0 1 0 0];[(-k1prm-k12prm)/m 0 k12prm*ksens1/ksens2/m 0];[0 0 0 1];[k12prm*ksens2/ksens1/m 0 (k2prm-k12prm)/m 0]]
	B=[[0 0];[ku1str*ksens1/m 0];[0 0];[0 ku2str*ksens2/m]]
	C=[[1 0 0 0];[0 0 1 0]] % y1 and y2 as outputs, change as desired
end
if modeltype==2
	k1prm=0
	k2prm=0
	ksens=10^6
	ku=10^(-4)
	ksys=ku*ksens % System gain (N/m)
	u1o=(W+c/(y12o+d)^4)/ku
	u2o=(W-c/(y12o+d)^4)/ku
	Num11 = ksys*[m 0 k12prm]/m^2
	Num12 = ksys*k12prm/m^2
	Num21 = ksys*k12prm/m^2
	Num22 = ksys*[m 0 k12prm]/m^2
	Den = [1 0 2*k12prm/m 0 0]
	A=[[0 1 0 0];[-k12prm/m 0 k12prm/m 0];[0 0 0 1];[k12prm/m 0 -k12prm/m 0]]
	B=[[0 0];[ksys/m 0];[0 0];[0 ksys/m]]
	C=[[1 0 0 0];[0 0 1 0]] % y1 and y2 as outputs, change as desired
end

if SIMO==1
	B=B(:,1)
	Num1=Num11
	Num2=Num12
	Num21=[]
	Num22=[]
end


