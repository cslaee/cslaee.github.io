% This script finds the coefficients for the magnetic actuator linearization / calibration 
% using the assumed form of the correction which is linear in the parameter a
% For Model 730 Apparatus, The upper magnetic field characteristic may be considered to 
% the mirror image of the lower ==> The UPPER field coefficent a is the same as for the  
% LOWER, and b is the negative of that of the lower


% Measured magnet height, CHANGE TO NEGATIVE VALUES FOR ACTUATOR #2
Ymeasured=[0 0.49 0.88 1.22 1.83 2.29 2.69 3.03 3.60 4.05]';
% Uncompensated Control Effort input
Utest=[3050 4000 5000 6000 8000 10000 12000 14000 18000 22000]';
% Specify offset parameter, b
b=6.2;
% Input Magnet mass in Kg
m=0.121
W=m*9.81 % magnet weight

% Construct the correction function array
X=[(Ymeasured+b).^4];
% Solve for the coefficient vector abcd via regression using the backslash operator
% Divide by W to normalize force to N
a=X\(Utest/W);
% Create vector of evaluation points for correction function
Y_eval=(0:0.1:4.5)';
% Evaluate function at points.  Multiply by W to show as-tested case
Ueval=[(Y_eval+b).^4]*a*W;

% Plot
plot(Ymeasured,Utest,'o',Y_eval,Ueval,'-'),grid,%axis([0 4.5 0 25000])
ylabel('Conrol Effort Required to Produce Force Equal to Magnet Weight (counts)')
xlabel('Magnet Position (cm)')
title('u1 Actuator Characteristic / Pre-correction')
a1=a
b1=b
a2=a
b2=-b
