% PDPOLEPACE.M
% This script first solves for the PD gains kp & kd for the collocated inner 
% loop, then S(s)/R(s) for pole placement control of theta
% You must first run MIMOplant.m set to SIMO=1
% For discrete implementation, input sampling rate (sec)
Ts=0.001768;  

% INNER LOOP PD CONTROL
% Input desired natural frequency, wnhz (Hz), and damping ratio, z
wnhz=8;
wn=wnhz*2*pi;
z=.707;

% Calculate inner loop kp & kd.
kp=wn^2*m/ksys
kd=2*z*sqrt(m*kp/ksys)

% For mechanical parameter forms of Nstr, & Dstr: (Comment out if not used)
%Designate damping coefficient, c
c_=8*m
Nstr=k12prm/m
Dstr=[1 c_/m k12prm/m]


% OUTER LOOP POLE PLACEMENT CONTROL
% Input desired closed loop poles, pi to construct desired closed loop denominator, Dcl:
% Specify wclhz (Hz) for poles at 135, 180, & 225 deg.
wclhz=4,
wcl=wclhz*2*pi;
p1=-wcl/sqrt(2)*(1+i);
p2=-wcl/sqrt(2)*(1-i);
p3=-2*wcl;
% The following is for third order Butterworth poles.  These provide a faster rise time 
% but with more overshoot than the above; decomment if preferred (Poles at 120, 180, & 240 deg.)
%p1=-wcl/2*(1+sqrt(3)*i);
%p2=-wcl/2*(1-sqrt(3)*i);
%p3=-wcl;
%Create specified closed loop denominator
Dcl=poly([p1;p2;p3]);
% Solve Diophantine Equation for S(s) & R(s) via Sylvester matrix
SYLVa=toeplitz([Dstr zeros(1,1)],zeros(1,2));
SYLVb=toeplitz([[0 0 Nstr] zeros(1,1)],zeros(1,2))
SYLV=[SYLVa SYLVb];
SR=SYLV\Dcl';
S=SR(3:4)'
R=SR(1:2)'
kpf=(R(2)*Dstr(3)+S(2)*Nstr)/Nstr
% For discrete implementation use Sd(z) & Rd(z)
%[Sd,Rd]=c2dm(S,R,ts,'tustin')

%Plot simulation of idealized (c(s)=1) closed loop system
t=0:.02:2;
Ncli=kpf*Nstr;
Dcli=[0 0 conv(Nstr,S)]+conv(Dstr,R);
stepi=step(Ncli,Dcli,t);
plot(t,stepi),grid,pause

%Solve for the discrete time outer loop controller coefficients using FOH conversion
H=tf(S,R)
Hd=c2d(H,Ts,'tustin')


