% This script finds the inertia elements KA, IC, JC, & KC.  You must first  
% have run "Massproperties.m". 
% WARNING, this script will over-write the inertia elements KA, IC, JC, & KC
% from "Massproperties.m". 

%INPUT PARAMETERS
%First for JC test, then for KA test, then for IC test,
%JC tests
v1_endpos=18400; %Velocity at end of positive control effort leg (counts/sec)
v1_endneg=-2568; %Velocity at end of negative control effort leg (counts/sec)
v3_endpos=-17120; %Velocity at end of positive control effort leg (counts/sec)
v3_endneg=3810; %Velocity at end of negative control effort leg (counts/sec)
%KA tests
v1_endpos2=29000; %Velocity at end of positive control effort leg (counts/sec)
v1_endneg2=-4404; %Velocity at end of negative control effort leg (counts/sec)
v4_endpos=-12545; %Velocity at end of positive control effort leg (counts/sec)
v4_endneg=2900; %Velocity at end of negative control effort leg (counts/sec)
%IC tests
%v2_endpos=28000; %Velocity at end of positive control effort leg (counts/sec)
%v2_endneg=-2000; %Velocity at end of negative control effort leg (counts/sec)
%v4_endpos2=-4500; %Velocity at end of positive control effort leg (counts/sec)
%v4_endneg2=-350; %Velocity at end of negative control effort leg (counts/sec)
v2_endpos=51000; %Velocity at end of positive control effort leg (counts/sec)
v2_endneg=-9420; %Velocity at end of negative control effort leg (counts/sec)
v4_endpos2=-7750; %Velocity at end of positive control effort leg (counts/sec)
v4_endneg2=1605; %Velocity at end of negative control effort leg (counts/sec)


% CALCULATIONS FOR JC
v1_o1=0;
v1_f1=v1_endpos/6667*2*pi; %Final velocity of rotor relative to frame C, first segment, (from encoder 1, rad/s)
v1_o2=v1_f1;
v1_f2=v1_endneg/6667*2*pi; %Final velocity of rotor relative to frame C, second segment, (from encoder 1, rad/s)
w3_o1=0;
w3_f1=v3_endpos/16000*2*pi; %Final velocity of frame C realtive to ground, first segment (from encoder 3, rad/s)
w3_o2=w3_f1;
w3_f2=v3_endneg/16000*2*pi; %Final velocity of frame C realtive to ground, second segment (from encoder 3, rad/s)
w1_o1=0;
w1_f1=w3_f1+v1_f1; %velocity of rotor relative to ground (inertial frame, rad/s)
w1_o2=w1_f1;
w1_f2=w3_f2+v1_f2;
%From Cons of angular momentum: JD*w1_o+(JC+JB)*w3_o = JD*w1_f+(JC+JB)*w3_f
JC1=-JD*(w1_f1-w1_o1)/(w3_f1-w3_o1)-JB
JC2=-JD*(w1_f2-w1_o2)/(w3_f2-w3_o2)-JB
JC=(JC1+JC2)/2


% CALCULATIONS FOR KA
v1_o1=0;
v1_f1=v1_endpos2/6667*2*pi; %Final velocity of rotor relative to frame C, first segment, (from encoder 1, rad/s)
v1_o2=v1_f1;
v1_f2=v1_endneg2/6667*2*pi; %Final velocity of rotor relative to frame C, second segment, (from encoder 1, rad/s)
w4_o1=0;
w4_f1=v4_endpos/16000*2*pi; %Final velocity of frame A realtive to ground, first segment (from encoder 4, rad/s)
w4_o2=w4_f1;
w4_f2=v4_endneg/16000*2*pi; %Final velocity of frame A realtive to ground, second segment (from encoder 4, rad/s)
w1_o1=0;
w1_f1=w4_f1+v1_f1; %velocity of rotor relative to ground (inertial frame, rad/s)
w1_o2=w1_f1;
w1_f2=w4_f2+v1_f2;
%From Cons of angular momentum: JD*w1_o+(JC+KB+KA)*w4_o = JD*w1_f+(JC+KB+KA)*w4_f
KA1=-JD*(w1_f1-w1_o1)/(w4_f1-w4_o1)-JC-KB
KA2=-JD*(w1_f2-w1_o2)/(w4_f2-w4_o2)-JC-KB
KA=(KA1+KA2)/2


% CALCULATIONS FOR IC
v2_o1=0;
v2_f1=v2_endpos/24400*2*pi; %Final velocity of frame C relative to A & B, first segment, (from encoder 2, rad/s)
v2_o2=v2_f1;
v2_f2=v2_endneg/24400*2*pi; %Final velocity of frame C relative to A & B, second segment, (from encoder 2, rad/s)
w4_o1=0;
w4_f1=v4_endpos2/16000*2*pi; %Final velocity of frame A realtive to ground, first segment (from encoder 4, rad/s)
w4_o2=w4_f1;
w4_f2=v4_endneg2/16000*2*pi; %Final velocity of frame A realtive to ground, second segment (from encoder 4, rad/s)
w2_o1=0;
w2_f1=w4_f1+v2_f1; %velocity of rotor relative to ground (inertial frame, rad/s)
w2_o2=w2_f1;
w2_f2=w4_f2+v2_f2;
%From Cons of angular momentum: (ID+IC)*w2_o+(IB+KA)*w4_o = (ID+IC)*w21_f+(IB+KA)*w4_f 
IC1=-(IB+KA)*(w4_f1-w4_o1)/(w2_f1-w2_o1)-ID
IC2=-(IB+KA)*(w4_f2-w4_o2)/(w2_f2-w2_o2)-ID
IC=(IC1+IC2)/2

