%  This script generates a family of LQR controllers and plots the
%  resulting closed loop poles, step and frequency responses.  You must  
%  first have generated the A,B, & C matrices. 

%CC=[1 0 0];
CC=C;
Q=CC'*CC;
Aol=A;
BB=B;

Klqr1=lqr(Aol,BB,Q,100);
Klqr2=lqr(Aol,BB,Q,10);
Klqr3=lqr(Aol,BB,Q,1)
Klqr4=lqr(Aol,BB,Q,.05)
Klqr5=lqr(Aol,BB,Q,.01)


% Find prefilter gain depending on realization (axis to be controlled) 
% See PlantSpecial2.m for definitions and to set keepq
if keepq==4
	kpf1=Klqr1(1);
	kpf2=Klqr2(1);
	kpf3=Klqr3(1)
	kpf4=Klqr4(1)
	kpf5=Klqr5(1)
end
if keepq==2
	kpf1=Klqr1(1)+D(3)/N2(1);
	kpf2=Klqr2(1)+D(3)/N2(1);
	kpf3=Klqr3(1)+D(3)/N2(1)
	kpf4=Klqr4(1)+D(3)/N2(1)
	kpf5=Klqr5(1)+D(3)/N2(1)
end

Pcl1=eig(Aol-BB*Klqr1)/2/pi;
Pcl2=eig(Aol-BB*Klqr2)/2/pi;
Pcl3=eig(Aol-BB*Klqr3)/2/pi;
Pcl4=eig(Aol-BB*Klqr4)/2/pi;
Pcl5=eig(Aol-BB*Klqr5)/2/pi;

% Plot Roots
axis([-8,1,-8,8])
plot(Pcl1,'x')
hold;
plot(Pcl2,'o');
plot(Pcl3,'*');
plot(Pcl4,'+');
plot(Pcl5,'.');
plot(Pcl5,'o');
title('LQR Controller, Closed Loop Poles For Various Control Effort Weights')
xlabel('Real  (Hz)')
ylabel('Imaginary  (Hz)')
grid;
hold;
pause

%For plotting loci @ intermediate Klqr:
%n=50;
%r=logspace(-2,2,n);
%for j=1:n
%  Klqr(j,:)=lqr(Aol,BB,Q,r(j));
%  Pcl(:,j)=eig(Aol-BB*Klqr(j,:))/2/pi;
%end
%plot(Pcl,'.')

% Continuous time step responses:


t=0:.01:1;

steplq1=kpf1*step([Aol-BB*Klqr1],BB,C,0,1,t);
steplq2=kpf2*step([Aol-BB*Klqr2],BB,C,0,1,t);
steplq3=kpf3*step([Aol-BB*Klqr3],BB,C,0,1,t);
steplq4=kpf4*step([Aol-BB*Klqr4],BB,C,0,1,t);
steplq5=kpf5*step([Aol-BB*Klqr5],BB,C,0,1,t);



%Example Step Response Plot
plot(t,[steplq3 steplq4 steplq5]);
%plot(t,[steplq1]);
xlabel('Time  (sec)'),grid
if keepq==4
	title('Step Response, Output @ q4')
	ylabel('Axis 4 Response')
end
if keepq==2
	title('Step Response, Output @ q2')
	ylabel('Axis 2 Response')
end


