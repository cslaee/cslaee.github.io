% This script gives a family of root loci for various ratios of PD 
% gains kp & kd for outer loop in the the successive loop / PD control of 
% the vertical axis, Axis 4. You must have first run MassProprties.m
% MeasInertia.m, "Drivegain.m", PlantSpecial2.m, and NutnDampRlocus.m 
% or input parameters manually. 

% FROM NutnDampRlocus.m YOU MUST SELECT A SINGLE RATE FEEDBACK GAIN 
% VALUE, kv, AND INPUT BELOW.

kv=0.08 % Input inner loop rate feedback gain

Dstr=D+[0 conv(N2,[kv 0])]; % Denominator net of inner loop

% Generate & Plot Family of Root Loci
subplot(2,2,1)
rlocus(conv(N4,-[.01 1]),Dstr) % kp & kd negative - must make them so in real-time algorithm also
[Ra,kpa]=rlocus(conv(N4,-[.01 1]),Dstr); %List R and kp from case a, b, c, or d after viewing root loci
title('kd = 0.01 kp')
xlabel('Real (rad/s)')
ylabel('Imaginary (rad/s)')
axis([-110,20,-55 55])
VV=axis;
grid

subplot(2,2,2)
rlocus(conv(N4,-[.02 1]),Dstr)
[Rb,kpb]=rlocus(conv(N4,-[.02 1]),Dstr);
title('kd = 0.02 kp')
xlabel('Real (rad/s)')
ylabel('Imaginary (rad/s)')
axis(VV)
grid

subplot(2,2,3)
rlocus(conv(N4,-[.05 1]),Dstr)
[Rc,kpc]=rlocus(conv(N4,-[.05 1]),Dstr);
title('kd = 0.05 kp')
xlabel('Real (rad/s)')
ylabel('Imaginary (rad/s)')
axis(VV)
grid

subplot(2,2,4)
rlocus(conv(N4,-[.1 1]),Dstr)
[Rc,kpc]=rlocus(conv(N4,-[.1 1]),Dstr);
title('kd = 0.1 kp')
xlabel('Real (rad/s)')
ylabel('Imaginary (rad/s)')
axis(VV)
grid
