%This Script generates the second order state space realization and transfer  
%functions of the CMG system for the case when all gimbals are locked except 
%axis #3. The plant input is torque about Axis 3 which is reacted 
%against the rotor Inertia You must first have run "Massproperties.m", 
%and also "inertiaMeas.m" and "Drivegain.m" or input parameters manually.

modeltype=2  % Choose plant model type: 0 = Dynamic model in consistent SI units
			 % without sensor and control effort gains.   1 = Model including sensor and control
			 % effort gains where control effort is in Volts and encoder gain does not have ks=32  
			 % factor.  This form is consistent with a Model 750 system sold in "plant only" form.  
			 % 2 = Model including sensor and control effort effort gains with control effort 
			 % in counts.  This form is consistent with a Model 750 system sold as a complete 
			 % system using the DSP control board
ke3=2547*32;

if modeltype==0
	A1=[0 1];
	A2=[0 0];
	
	B1=[0];
	B2=[-1/(JB+JC)];
	
	A=[A1;A2]
	B=[B1;B2]
	C=[1 0]
	
	N=-1;
	D=[JB+JC 0 0];
	N=N/D(1),D=D/D(1) %Makes D monic
end

if modeltype==1
	A1=[0 1];
	A2=[0 0];
	
	B1=[0];
	B2=[-1/(JB+JC)*ku1/kc*ke3/32];
	
	A=[A1;A2]
	B=[B1;B2]
	C=[1 0]
	
	N=-ke3/32*ku1/kc;
	D=[JB+JC 0 0];
	N=N/D(1),D=D/D(1) %Makes D monic
end

if modeltype==2   %Same as modeltype 1 except no division of ku's by kc nor of ke's by 32
	A1=[0 1];
	A2=[0 0];
	
	B1=[0];
	B2=[-1/(JB+JC)*ku1*ke3];
	
	A=[A1;A2]
	B=[B1;B2]
	C=[1 0]
	
	N=-ke3*ku1;
	D=[JB+JC 0 0];
	N=N/D(1),D=D/D(1) %Makes D monic
end
