% This Script generates the fourth order state space realization and transfer
% functions of the CMG system for the case when Axis 3 is locked, w2 is prescribed 
% (i.e. it is an input), and q2o=0, q3o=0. You must first have run "Massproperties.m",
%  and also "inertiaMeas.m" and "Drivegain.m" or input parameters manually.

%Specify nominal rotor speed
omega_RPM=400 % RPM
modeltype=2  % Choose plant model type: 0 = Dynamic model in consistent SI units
			 % without sensor and control effort gains.   1 = Model including sensor and control
			 % effort gains where control effort is in Volts and encoder gain does not have ks=32  
			 % factor.  This form is consistent with a Model 750 system sold in "plant only" form.  
			 % 2 = Model including sensor and control effort effort gains with control effort 
			 % in counts.  This form is consistent with a Model 750 system sold as a complete 
			 % system using the DSP control board
			 
omega=omega_RPM*2*pi/60;
ke2=3883*32;
ke4=2547*32;

if modeltype==0
	A1=[0 1];
	A2=[0 0];
	
	B1=[0];
	B2=[-JD*omega/(ID+KA+KB+KC)];
	
	A=[A1;A2]
	B=[B1;B2]
	C=[1 0]
	N=JD*omega;
	D=[(ID+KA+KB+KC) 0 0];
	N=N/D(1),D=D/D(1) %Makes D monic
end

if modeltype~=0 %Model types 1 & 2 are the same in this case
	
	A1=[0 1];
	A2=[0 0];
	
	B1=[0];
	B2=[-JD*omega/(ID+KA+KB+KC)*ke4/ke2];
	
	A=[A1;A2]
	B=[B1;B2]
	C=[1 0]
	
	N=JD*omega*ke4/ke2;
	D=[(ID+KA+KB+KC) 0 0];
	N=N/D(1),D=D/D(1) %Makes D monic
end
