
% This script builds a 7th order state space realization of the plant linearized about any
% set of gimbal angles {q20, q30, q30}.  You must first have run "Massproperties.m",
% "InertiaMeas.m" and "Drivegain.m" or input parameters manually.

%SPECIFY PARAMETERS
omega_RPM=400 % Nominal wheel speed in RPM
q20=50 % Nominal position, Gimbal #2 (deg)
q30=-50 % Nominal position, Gimbal #3 (deg) 

minimal=1    % Set =0 for 7 states: X=[q2 q3 q4 w1 w2 w3 w4]', Set =1 for 5 states: X=[q3 q4 w2 w3 w4]'

modeltype=2  % Choose plant model type: 1=Dynamic model in consistent SI units
			 % without sensor and control effort gains.  1=Model including sensor and control
			 % effort gains whre control effort is in Volts.  This form is consistent with
			 % a Model 750 system sold in "plant only" form.  2= Model including sensor and 
			 % control effort effort gains with control effort in counts.  This form is consistent
			 % with a Model 750 system sold as a complete system using the DSP control board
			 
omega=omega_RPM*2*pi/60;
ke1=1061*32;
ke2=3883*32;
ke3=2547*32;
ke4=2547*32;
s2=sin(q20*pi/180);
s3=sin(q30*pi/180);
c2=cos(q20*pi/180);
c3=cos(q30*pi/180);

% Eq's 5.3-4 through 5.3-7  have the form: E*Xdot=A_str*X+B_str*U 
% Solve to Find A and B, i.e. A=inv(E)*A_str, B=inv(E)*_Bstr.

E1=[1 0 0 0 0 0 0];
E2=[0 1 0 0 0 0 0];
E3=[0 0 1 0 0 0 0];
E4=[0 0 0 JD 0 JD*c2 JD*s2*c3];
E5=[0 JD*omega*s2 -JD*omega*c2*c3 0 (IC+ID) 0 -s3*(IC+ID)];
E6=[-JD*omega*s2 0 JD*omega*s2*s3 JD*c2 0 (JB+JC+JD-s2^2*(JC+JD-ID-KC)) s2*c2*c3*(JC+JD-ID-KC)];
E7=[JD*omega*c2*c3 -JD*omega*s2*s3 0 JD*s2*c3 -s3*(IC+ID) s2*c2*c3*(JC+JD-ID-KC) (ID+KA+KB+KC+s2^2*(JC+JD-ID-KC)+s3^2*(IB+IC-KB-KC-s2^2*(JC+JD-ID-KC)))];

E=[E1;E2;E3;E4;E5;E6;E7];

A_str=[[0 0 0 0 1 0 0];[0 0 0 0 0 1 0];[0 0 0 0 0 0 1];zeros(4,7)];
B_str=[zeros(3,2);eye(2,2);zeros(2,2)];
A=inv(E)*A_str;
B=inv(E)*B_str;
C=[eye(3,3) zeros(3,4)];

if minimal==0
	% ADD GAIN SCALING
	if modeltype~=0
		Ke=[0 0 0 ke1,ke2,ke3,ke4];
		Ku=[ku1,ku2];
		for i=4:7
			for j=5:7
				A(i,j)=A(i,j)*Ke(i)/Ke(j);
			end
			for j=1:2
				if modeltype==1
					B(i,j)=B(i,j)*Ku(j)/kc*Ke(i)/32;
				end
				if modeltype==2
					B(i,j)=B(i,j)*Ku(j)*Ke(i);
				end
			end
		end
	end
end

if minimal==1
	A1=[0 0 0 1 0];
	A2=[0 0 0 0 1];
	A3=A(5,3:7);
	A4=A(6,3:7);
	A5=A(7,3:7);
	A=[A1;A2;A3;A4;A5];
	B=[zeros(2,2);B(5:7,:)];
	C=[eye(2,2) zeros(2,3)];
	% ADD GAIN SCALING
	if modeltype~=0
		Ke=[0 0 ke2,ke3,ke4];
		Ku=[ku1,ku2];
		for i=3:5
			for j=3:5
				A(i,j)=A(i,j)*Ke(i)/Ke(j);
			end
			for j=1:2
				if modeltype==1
					B(i,j)=B(i,j)*Ku(j)/kc*Ke(i)/32;
				end
				if modeltype==2
					B(i,j)=B(i,j)*Ku(j)*Ke(i);
				end
			end
		end
	end
end

A,B,C
