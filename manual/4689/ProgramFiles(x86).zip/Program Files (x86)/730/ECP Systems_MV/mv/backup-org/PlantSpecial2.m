% This Script generates the fourth order state space realization and transfer
% functions of the CMG system for the case when Axis 3 is locked, all others are
% free and, q2o=0, q3o=0. You must first have run "Massproperties.m", and also 
% "inertiaMeas.m" and "Drivegain.m" or input parameters manually. 

% Specify nominal rotor speed
omega_RPM=400 % RPM

modeltype=2  % Choose plant model type: 0 = Dynamic model in consistent SI units
			 % without sensor and control effort gains.   1 = Model including sensor and control
			 % effort gains where control effort is in Volts and encoder gain does not have ks=32  
			 % factor.  This form is consistent with a Model 750 system sold in "plant only" form.  
			 % 2 = Model including sensor and control effort effort gains with control effort 
			 % in counts.  This form is consistent with a Model 750 system sold as a complete 
			 % system using the DSP control board
			 
minmodel=0	 % Choose whether state space realization should be minimal (minmodel =1) or should 
			 % include all modeled states q2, q4, w2, w4 (minmodel=0)
			 
keepq=4		 % If minmodel =1, chose whether to keep q2 (keepq=2) or q4 (keepq=4).  If keepq=2
			 % realization is second order and states are [q2 w2]'; if keepq=4, realization is
			 % third order and states are [q4 w2 w4]'; 
			 
omega=omega_RPM*2*pi/60;
ke2=3883*32;
ke4=2547*32;

if modeltype==0
	A1=[0 0 1 0];
	A2=[0 0 0 1];
	A3=[0 0 0 JD*omega/(IC+ID)];
	A4=[0 0 -JD*omega/(ID+KA+KB+KC) 0];

	A=[A1;A2;A3;A4]
	B=[0;0;1/(IC+ID);0]
	C=[[1 0 0 0];[0 1 0 0]]
	
	N2=[ID+KA+KB+KC 0]; % Numerator of q2(s)/T2(s)
	N4=-JD*omega; % Numerator of q4(s)/T2(s)
	D=[(IC+ID)*(ID+KA+KB+KC) 0 omega^2*JD^2 0]; % Denominator of q2(s)/T2(s) and q4(s)/T2(s)
	N2=N2/D(1),N4=N4/D(1),D=D/D(1) %Makes D monic
end

if modeltype==1
	A1=[0 0 1 0];
	A2=[0 0 0 1];
	A3=[0 0 0 JD*omega/(IC+ID)*ke2/ke4];
	A4=[0 0 -JD*omega/(ID+KA+KB+KC)*ke4/ke2 0];

	A=[A1;A2;A3;A4]
	B=[0;0;1/(IC+ID)*ku2/kc*ke2/32;0]
	C=[[1 0 0 0];[0 1 0 0]]
	
	N2=[ID+KA+KB+KC 0]*ke2/32*ku2/kc;
	N4=-JD*omega*ke4/32*ku2/kc;
	D=[(IC+ID)*(ID+KA+KB+KC) 0 omega^2*JD^2 0];
	N2=N2/D(1),N4=N4/D(1),D=D/D(1) %Makes D monic
end

if modeltype==2   %Same as modeltype 1 except no division of ku's by kc nor of ke's by 32
	A1=[0 0 1 0];
	A2=[0 0 0 1];
	A3=[0 0 0 JD*omega/(IC+ID)*ke2/ke4];
	A4=[0 0 -JD*omega/(ID+KA+KB+KC)*ke4/ke2 0];

	A=[A1;A2;A3;A4]
	B=[0;0;1/(IC+ID)*ku2*ke2;0]
	C=[[1 0 0 0];[0 1 0 0]]
	
	N2=[ID+KA+KB+KC 0]*ke2*ku2;
	N4=-JD*omega*ke4*ku2;
	D=[(IC+ID)*(ID+KA+KB+KC) 0 omega^2*JD^2 0];
	N2=N2/D(1),N4=N4/D(1),D=D/D(1) %Makes D monic
	
end

if minmodel==1
	if keepq==4
		A=A(2:4,2:4)
		B(1)=[]
		C=C(2,2:4)
	end
	if keepq==2
		A=[A1(2:3);[A3(4)*A4(3) 0]]
		B(2)=[];B(3)=[],
		C(2,:)=[];C(4)=[];C(3)=[]
	end
end
