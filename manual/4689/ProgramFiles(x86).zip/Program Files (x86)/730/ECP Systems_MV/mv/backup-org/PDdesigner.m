% Finds proportional & derivative gains (kp & kd) for various SISO models
% You must first have run the proper plant model or input parameters manually 
% INPUTS
plantloc=1   % Choose Plant Location (1= Axis 3 control via spin motor (Motor #1), 2= Axis 2 control
			 % via Motor #2)
wn=3 % Desired closed loop natural frequency, location 1, Hz
z=1
% Desired closed loop damping ratio, location 1


if plantloc==1
	Jprime=(JB+JC)/ku1/ke3
end
if plantloc==2
	Jprime=(IC+ID)/ku2/ke2
end

kp=Jprime*(wn*2*pi)^2
kd=2*z*wn*(2*pi)*Jprime

tt=0:.01:1;
step((wn*2*pi)^2, [1 z*wn*4*pi (wn*2*pi)^2], tt), grid
pause
bode((wn*2*pi)^2, [1 z*wn*4*pi (wn*2*pi)^2]), grid

	
		


