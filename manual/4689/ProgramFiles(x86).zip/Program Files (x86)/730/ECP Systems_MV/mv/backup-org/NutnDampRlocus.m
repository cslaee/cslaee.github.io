% This script gives the root locus of the Special Case #2 system 
% for rate feedback at Axis 2. You must have first run MassProprties.m
% MeasInertia.m, "Drivegain.m", and PlantSpecial2.m or input parameters manually.


[R,kv]=rlocus(conv(N2,[1 0]),D);
[R/2/pi kv'] %output: first three columns are the roots, last is kv
rlocus(conv(N2,[1 0]),D); grid
