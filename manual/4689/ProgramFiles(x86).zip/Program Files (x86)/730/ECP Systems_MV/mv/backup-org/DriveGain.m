% This script finds drive constants for motors 1 and 2. Choose "calctype to use either nominal
% parametrs or thosed measured from Newton's second law and Gyroscopic torque relationship.  
% You must first have run "Massproperties.m". 

calctype=1  % Choose calculation type: 0 = kui gains generated using nominal hardware parameters
			 %                         1 = kui gains generated using measured dynamic behavior
			 % effort gains where control effort is in Volts and encoder gain does not have ks=32  
			 % factor.  This form is consistent with a Model 750 system sold in "plant only" form.  
			 % 2 = Model including sensor and control effort effort gains with control effort 
			 % in counts.  This form is consistent with a Model 750 system sold as a complete 
			 % system using the DSP control board
			 
% INPUT PARAMETERS IF "calctype"=1
% First for Drive 1 test, then for Drive 2
% Drive #1
u1=16000; %Control effort during rotor acceleration (abs value, counts)
Taccel=4.000; %Duration of each leg of step series (sec)
v_endpos=48100; %Velocity at end of positive control effort leg (counts/sec)
v_endneg=-10850; %Velocity at end of negative control effort leg (counts/sec)

% Drive #2
W1=400; % Rotor Speed, RPM
w4pos=3000; % Pos yoke velocity (counts/sec)
w4neg=-3000; % Neg yoke velocity (counts/sec)
u2V_w4pos=-4.5; % Control effort2 when w4=w4pos (V)
u2V_w4neg=4.55; % Control effort2 when w4=wneg (V)

if calctype==0
	kc=10/(2^15);
	ka=0.40;
	kt1=0.053;
	kt2=0.12;
	kp1=3.33;
	kp2=6.1;
	ku1=kc*ka*kp1*kt1
	ku2=kc*ka*kp2*kt2
end

if calctype==1
	% CALCULATIONS FOR DRIVE 1
	Accelavg=((v_endpos-0)-(v_endneg-v_endpos))/(2*Taccel)/6667*2*pi; %Avg accel (rad/s^2).  Encoder res. is 4000 count/rev.
	% Newton's Second Law in rotational form:  T = J*wdot
	T1avg=JD*Accelavg;
	% Find Drive Gain Term
	ku1=T1avg/u1
	% Use the following only if kt is desired explicitly
	ka=0.40; %Amplifier gain, Amperes/Volt
	kp1=2; %Belt drive pulley diameter ratio ("gear ratio")
	kc=10/(2^15);
	kt1=ku1/ka/kp1/kc;

	% CALCULATIONS FOR DRIVE 2
	% Calculate Terms
	Hrotor=JD*W1*2*pi/60; %Rotor momentum kg-m^2/s
	w4avg=((w4pos+(-w4neg))/2)/16000*2*pi; %Avg yoke velocity (rad/s)
	% Solve Gyroscopic Cross Product: T = w X H
	T21=-(w4pos/16000*2*pi)*Hrotor; 
	T22=-(w4neg/16000*2*pi)*Hrotor;
	% Find Drive Gain Term
	kc=10/(2^15);
	ku21=T21/(u2V_w4pos/kc);
	ku22=T22/(u2V_w4neg/kc);
	ku2=(ku21+ku22)/2
	% Use the following only if kt is desired explicitly
	kp2=6.1; %Capstan pulley ratio ("gear ratio")
	ka=0.40; %Amplifier gain, Amperes/Volt
	kc=10/32768;
	kt2=ku2/kc/ka/kp2;
end
