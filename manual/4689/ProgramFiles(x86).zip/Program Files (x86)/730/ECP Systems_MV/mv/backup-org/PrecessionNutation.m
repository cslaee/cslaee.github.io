% This script solves for the expected precession, w, for constant input torque T2,  
% and for the nutation frequency and mode shape as a function of rotor speed. You
% must have first run MassProprties.m, MeasInertia, and Drivegain.m

W1=400 % Rotor Speed, RPM
ControlEffort2=6000; % Gimbal 2 control effort (counts) - precession tests
q2steadystate=205; % Value of q2 when w4 @ initial steady state (counts) - used in
				   % cons. of ang. momentum calculation

% PRECESSION EQUATIONS
Hrotor=JD*W1*2*pi/60; %Rotor momentum kg-m^2/s
w_rad=ControlEffort2*ku2/Hrotor % Precession rate (rad/sec)
w_deg=w_rad*180/pi % Precession rate (deg/sec)
w_counts=w_rad/2/pi*16000 % Precession rate (counts/sec)

% NUTATION EQUATIONS
ke2=3883*32; %Encoder 2 gain
ke4=2547*32; %Encoder 4 gain
J2=(IC+ID);
J4=(ID+KA+KB+KC);
beta=JD*sqrt(1/J2/J4);
gamma=sqrt(J2/J4);
nutationfreq=beta*(W1*2*pi/60)
nutationfreqHz=nutationfreq/2/pi
modeshape=[1 gamma]
modeshape_counts=[1 gamma*ke4/ke2]

% EXPECTED PRECESSION VIA CONSERVATION OF ANGULAR MOMENTUM AND MEASURED Q2 (assumes
% small angle q2)
q2ss=q2steadystate/(ke2/32); %radians
w4_expected=-Hrotor*sin(q2ss)/(J4) % Expected angular velocity w4 for q2o=0 (before T2 applied, rad/sec)
w4_expected_deg=w4_expected*180/pi
w4_expected_counts=w4_expected*ke4 % Expected angular velocity w4 for q2o=0 (before T2 applied, counts,sec)
