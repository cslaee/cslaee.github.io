% PDPOLEPACE.M 
% This script finds S(s)/R(s) for pole placement control of q4
% You must have first run MassProprties.m, MeasInertia.m, "Drivegain.m", 
% PlantSpecial2.m, and NutnDampRlocus.m or input parameters manually. 

% For discrete implementation, input sampling rate (sec)
%Ts=0.00884; 
Ts=0.00442

% CLOSED LOOP DENOMINATOR 
% Below is 5th order Butterworth pole distribution.  Change to other poles if desired.
% Input desired closed loop poles, pi to construct desired closed loop denominator, Dcl:
% Specify wclhz (Hz) 
wclhz=5,
wcl=wclhz*2*pi;
p1=-wcl*(sin(0.1*pi)+cos(0.1*pi)*i);
p2=-wcl*(sin(0.1*pi)-cos(0.1*pi)*i);
p3=-wcl*(sin(0.3*pi)+cos(0.3*pi)*i);
p4=-wcl*(sin(0.3*pi)-cos(0.3*pi)*i);
p5=-wcl

%Create specified closed loop denominator
Dcl=poly([p1;p2;p3;p4;p5])
% Solve Diophantine Equation for S(s) & R(s) via Sylvester matrix
SYLVa=toeplitz([D 0 0],zeros(1,3));
SYLVb=toeplitz([[0 0 0 N4 0 0]],zeros(1,3))
SYLV=[SYLVa SYLVb];
RS=SYLV\Dcl';
R=RS(1:3)'
S=RS(4:6)'
kpf=(R(3)*D(4)+S(3)*N4)/N4

%Plot simulation of idealized closed loop system
t=0:.01:1;
Ncli=kpf*N4;
%Dcli=[0 0 0 0 conv(N4,S)]+conv(D,R);
Dcli=[0 0 0 conv(N4,S)]+conv(D,R);
%stepi=step(Ncli,Dcli,t);
%plot(t,stepi),grid,pause
stepi=step(Ncli,Dcli,t);
plot(t,stepi),grid,pause

%Solve for the discrete time outer loop controller coefficients using Tustin conversion
H=tf(S,R)
Hd=c2d(H,Ts,'tustin')
[Sd,Rd]=c2dm(S,R,Ts,'tustin')
kpfd=(sum(Rd)*D(4)+sum(Sd)*N4)/N4


