%  The following generates a family of LQR controllers and plots the
%  resulting closed loop poles and step and singular value responses.
%  You must first have generated the A,& B,matrices. 


Cstr=[[1 0 0 0 0];[0 1 0 0 0]]
Q=Cstr'*Cstr;


Klqr1=lqr(A,B,Q,100*[[.1 0];[0 1]]);
Klqr2=lqr(A,B,Q,10*[[.1 0];[0 1]]);
Klqr3=lqr(A,B,Q,1*[[.1 0];[0 1]]);
Klqr4=lqr(A,B,Q,.1*[[.1 0];[0 1]]);
Klqr5=lqr(A,B,Q,.01*[[.1 0];[0 1]]);


Pcl1=eig(A-B*Klqr1)/2/pi;
Pcl2=eig(A-B*Klqr2)/2/pi;
Pcl3=eig(A-B*Klqr3)/2/pi;
Pcl4=eig(A-B*Klqr4)/2/pi;
Pcl5=eig(A-B*Klqr5)/2/pi;

% Plot Roots
plot(Pcl1,'x')
hold;
plot(Pcl2,'o');
plot(Pcl3,'*');
plot(Pcl4,'+');
plot(Pcl5,'.');
plot(Pcl5,'o');
title('LQR Controller, Closed Loop Poles For Various Control Effort Weights')
xlabel('Real  (Hz)')
ylabel('Imaginary  (Hz)')
axis equal
%axis([-20,0,-15,15])
grid;
hold;
pause
axis normal
% User may define other labels, frequencies in Hz.
% Stike any key to continue

%Generate Step Responses.  "-3" is response at q3 & q4 to commanded step
% in q3, "-4" is response at q3 & q4 to commanded step in q4
t=0:.01:2;
CC=[[1 0 0 0 0];[0 1 0 0 0]];
steplq1_3=step([A-B*Klqr1],B*Klqr1,CC,[0 0],1,t);
steplq1_4=step([A-B*Klqr1],B*Klqr1,CC,[0 0],2,t);
steplq2_3=step([A-B*Klqr2],B*Klqr2,CC,[0 0],1,t);
steplq2_4=step([A-B*Klqr2],B*Klqr2,CC,[0 0],2,t);
steplq3_3=step([A-B*Klqr3],B*Klqr3,CC,[0 0],1,t);
steplq3_4=step([A-B*Klqr3],B*Klqr3,CC,[0 0],2,t);
steplq4_3=step([A-B*Klqr4],B*Klqr4,CC,[0 0],1,t);
steplq4_4=step([A-B*Klqr4],B*Klqr4,CC,[0 0],2,t);
steplq5_3=step([A-B*Klqr5],B*Klqr5,CC,[0 0],1,t);
steplq5_4=step([A-B*Klqr5],B*Klqr5,CC,[0 0],2,t);

 
%Example Step Response Plot
plot(t,[steplq4_3 steplq4_4]),grid,axis([0,1,-.4,1.2]),
xlabel('Time (s)'),ylabel('Amplitude')
pause

%Singular value plots

syslqrcl3=ss([A-B*Klqr3],B*Klqr3,CC,0);
syslqrcl4=ss([A-B*Klqr4],B*Klqr4,CC,0);
syslqrcl5=ss([A-B*Klqr5],B*Klqr5,CC,0);
sigma(syslqrcl4,syslqrcl5)
%axis([1,200,-40,10])
%axis([1,2000,-100,10])
set(gca,'xtick',[1 2 3 4 5 6 7 8 9 10 20 30 40 50 60 70 80 90 100 200]),
