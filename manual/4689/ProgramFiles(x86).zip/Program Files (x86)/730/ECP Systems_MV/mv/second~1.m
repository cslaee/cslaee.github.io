%Finds the second order step and Bode responses
w=4 %Hz 
z=.5

W=w*2*pi;
N=W^2;
D=[1 2*z*W W^2];

step(N,D),grid
pause
Bode(N,D)
