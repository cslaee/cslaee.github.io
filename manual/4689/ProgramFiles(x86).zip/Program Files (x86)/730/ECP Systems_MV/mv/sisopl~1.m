% This script builds the linearized SISO plant model about some operating point, y1o,  
% u1o for the lower (repulsive) plant and y2o, u2o for the upper (attractive) plant.  
% You must first have run "sensorcal.m" and "actuatorcal.m" or input parameters manually

% INPUTS
plantloc=1   % Choose Plant Location (1=lower, 2=upper)
modeltype=0  % Choose plant model type (0=linearized about equilibrium 
			 % using raw sensor counts, 1=linearized about equilibrium
			 % using calibrated/corrected sensor, 2= operation throughout
			 % range, using corrected sensor & actuator
m=0.121  % magnet mass (kg)
W=m*9.81 % magnet weight
y1o=2 % Offset position1 (cm)
yraw1o=15000 % Raw sensor counts at equilibrium1 (counts)
y2o=-2 % Offset position2 (cm)
yraw2o=15400 % Raw sensor counts at equilibrium2 (counts)

% Model Building
if plantloc==1
	u1o=W*a1*(y1o+b1)^4 % Control effort actuator1 & equilibrium (counts)
	k1prm=4/(y1o+b1)*W*100 % Effective linearized spring constant (N/m)
	ku1str=1/(a1*(b1+y1o)^4) % Actuator gain (N/count)
	if modeltype==0
		ksens1=1/(-e1*(yraw1o)^(-2)-f1/2*(yraw1o)^(-1.5)+h1)*100 % Sensor gain at equilib (counts/m)
	end
	if modeltype==1
		ksens1=10^6 % Sensor gain (counts/m)
	end
	if modeltype~=2
		ksys1=ku1str*ksens1 % System gain (N/m)
		Num1=ksys1/m
		Den1=[1 0 k1prm/m]
		A1=[[0 1];[-k1prm/m 0]]
		B1=[0;ksys1/m]
		C1=[1 0]
	end
	if modeltype==2
		k1prm=0
		ksens1=10^6
		ku1=10^(-4)
		u10=W/ku1
		ksys1=ku1*ksens1 % System gain (N/m)
		Num1=ksys1/m
		Den1=[1 0 0]
		A1=[[0 1];[0 0]]
		B1=[0;ksys1/m]
		C1=[1 0]
	end
end
if plantloc==2
	u2o=W*a2*(y2o+b2)^4 % Control effort actuator2 & equilibrium (counts)
	k2prm=4/(y2o+b2)*W*100 % Effective linearized spring constant (N/m)
	ku2str=1/(a2*(b2+y2o)^4) % Actuator gain (N/count)
	if modeltype==0
		ksens2=1/(-e2*(yraw2o)^(-2)-f2/2*(yraw2o)^(-1.5)+h2)*100 % Sensor gain at equilib (counts/m)
	end
	if modeltype==1
		ksens2=10^6 % Sensor gain (counts/m)
	end
	if modeltype~=2
		ksys2=ku2str*ksens2 % System gain (N/m)
		Num2=ksys2/m
		Den2=[1 0 k2prm/m]
		A2=[[0 1];[-k2prm/m 0]]
		B2=[0;ksys2/m]
		C2=[1 0]
	end	
	if modeltype==2
		k2prm=0
		ksens2=10^6
		ku2=10^(-4)
		u20=W/ku2
		ksys2=ku2*ksens2 % System gain (N/m)
		Num2=ksys2/m
		Den2=[1 0 0]
		A2=[[0 1];[0 0]]
		B2=[0;ksys2/m]
		C2=[1 0]
	end
end
	
		


