%This script finds the coefficients for the magnet-to-magnet repulsive force as a function of
% magnet separation using the assumed form of the correction which is linear in the parameter a 


% Measured magnet height
Ymeas=[11.73 10.30 9.57 8.80 8.09 6.40 5.40 4.78 3.92 2.84]';
% Force applied at magnet
Force=[0.402 0.612 0.735 0.998 1.190 2.171 3.152 4.133 6.095 11.00]';
%Specify offset parameter, d (iterate this value to find best fit)
d=4.2

% Construct the correction function array
X=[(Ymeas+d).^(-4)];
% Solve for the coefficient c via regression using the backslash operator
c=X\Force;
% Create vector of evaluation points for correction function
Y_eval=(2.5:0.05:12)';
% Evaluate function at points
K12=[(Y_eval+d).^(-4)]*c;

% Plot
plot(Ymeas,Force,'o',Y_eval,K12,'-'),grid
ylabel('Magnet-to-Magnet Repulsive Force (N)')
xlabel('Magnet Separation - Distance (cm)')
title('Magnet-to-Magnet Force Characteristic')
