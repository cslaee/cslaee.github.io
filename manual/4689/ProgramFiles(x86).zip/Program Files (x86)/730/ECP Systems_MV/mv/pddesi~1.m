% Finds proportional & derivative gains (kp & kd) for various SISO models
% You must first have run "SISOplant.m" orinput parameters manually
% INPUTS 
plantloc=1   % Choose Plant Location (1=lower, 2=upper)
wn=4  % Desired closed loop natural frequency, location 1, Hz
z=.5% Desired closed loop damping ratio, location 1

if plantloc==1
	kp=(m*(wn*2*pi)^2-k1prm)/ksys1
	kd=2*z*wn*(2*pi)*m/ksys1 
end
if plantloc==2
	kp=(m*(wn*2*pi)^2-k2prm)/ksys2
	kd=2*z*wn*(2*pi)*m/ksys2 
end

	
	
	
		


