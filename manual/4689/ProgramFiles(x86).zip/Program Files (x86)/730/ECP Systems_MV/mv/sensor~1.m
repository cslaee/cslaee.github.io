% This script finds the coefficients for the sensor linearization / calibration
% using the assumed form of the correction which is linear in the  parameters{e,f,g,h}

%INPUTS
% Sensor Location (1=lower, 2=upper)
sensloc=1
% Actual magnet distance from mechanical stop (cm),
Yactual=[0 0.5 1 2 3 4 5 6]';
% Raw data from laser sensor at each height
Y1raw=[30000 25700 21600 14900 10400 7400 5300 3750]';
Y2raw=[29900 26300 22100 15300 10600 7600 5450 3920]';

% Construct the correction function array
% Solve for the coefficient vector efgh via regression using the backslash operator
if sensloc==1
	% Construct the correction function array
	X=[1./Y1raw sqrt(1./Y1raw) ones(size(Y1raw)) Y1raw];
	efgh=X\Yactual
	% Create vector of evaluation points for correction function
	Yraw_eval=(2000:100:30000)';
	% Evaluate function at points
	Ycal=[1./Yraw_eval sqrt(1./Yraw_eval) ones(size(Yraw_eval)) Yraw_eval]*efgh;
	e1=efgh(1),f1=efgh(2),g1=efgh(3),h1=efgh(4)

	% Plot
	plot(Y1raw,Yactual,'o',Yraw_eval,Ycal,'-'),grid,%axis([0 30000 -7 0])
	xlabel('Raw Sensor Output (counts)')
	ylabel('Magnet Position (cm)')
	title('y1 Sensor Calibration / Linearization')
end
if sensloc==2
	% Construct the correction function array
	X=[1./Y2raw sqrt(1./Y2raw) ones(size(Y2raw)) Y2raw];
	efgh=X\(-Yactual);
	e2=efgh(1),f2=efgh(2),g2=efgh(3),h2=efgh(4)
	% Create vector of evaluation points for correction function
	Yraw_eval=(2000:100:30000)';
	% Evaluate function at points
	Ycal=[1./Yraw_eval sqrt(1./Yraw_eval) ones(size(Yraw_eval)) Yraw_eval]*efgh;

	% Plot
	plot(Y2raw,-Yactual,'o',Yraw_eval,Ycal,'-'),grid,axis([0 30000 -7 0])
	xlabel('Raw Sensor Output (counts)')
	ylabel('Magnet Position (cm)')
	title('y2 Sensor Calibration / Linearization')
end

